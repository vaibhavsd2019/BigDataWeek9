package q1;

import java.io.IOException;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.conf.Configuration;


public class Run {


//Mapper

//@author Vaibhav M.
//Date: 12 October 2019
// Description: The run class for the Question1 ( the reducer and mapper are below)

public static class MaxTemperatureMapper extends
Mapper<LongWritable, Text, Text, Text> {
	 private TreeMap<Float, String> tmap1; 
/**
* @method map
* This method takes the input as text data type.
* Now leaving the first five tokens,it takes 6th token is taken as temp_max and
* 7th token is taken as temp_min. Now temp_max > 35 and temp_min < 10 are passed to the reducer.
*/

@Override
public void map(LongWritable arg0, Text Value, Context context)
throws IOException, InterruptedException {

//Converting the record (single line) to String and storing it in a String variable line
	 tmap1 = new TreeMap<Float, String>();
	 
String line = Value.toString();

//Checking if the line is not empty

if (!(line.length() == 0)) {

//year

String date = line.substring(6, 10);

//maximum temperature

float temp_Max = Float.parseFloat(line.substring(39, 45).trim());

tmap1.put( temp_Max,date);
if (tmap1.size() > 10) 
{ 
    tmap1.remove(tmap1.firstKey()); 
} 

for (Entry<Float, String> entry : tmap1.entrySet())  
{ 

   float count = entry.getKey(); 
   
   if (temp_Max !=9999.0) {
		 context.write(new Text(date), new Text(count+"")); 
	
   
} 

}


}
}

}

//Reducer

/**
*MaxTemperatureReducer class is static and extends Reducer abstract class
having four hadoop generics type Text, Text, Text, Text.
*/

public static class MaxTemperatureReducer extends
Reducer<Text, IntWritable, Text, Text> {
	private TreeMap<Float, Text> tmap; 
/**
* @method reduce
* This method takes the input as key and list of values pair from mapper, it does aggregation
* based on keys and produces the final context.
*/

public void reduce(Text Key, Iterable<FloatWritable> Values, Context context)
throws IOException, InterruptedException {

	tmap = new TreeMap<Float,Text>(); 
	
float maxValue = Float.MAX_VALUE;
for(FloatWritable value: Values){
maxValue = Math.max(maxValue, value.get());
}
float u= maxValue;

//putting all the values in temperature variable of type String


String temperature  = Float.toString(maxValue);

tmap.put(u, Key);
if (tmap.size() > 10) 
{ 
    tmap.remove(tmap.firstKey()); 
} 

for (Entry<Float, Text> entry : tmap.entrySet())  
{ 

   float count = entry.getKey(); 
   

    context.write(Key, new Text(count+"")); 
} 






}

}



/**
* @method main
* This method is used for setting all the configuration properties.
* It acts as a driver for map reduce code.
*/
public static void main(String[] args) throws Exception {

if(args.length !=2){
System.err.println("Usage: MaxTemperature <input path> <outputpath>");
System.exit(-1);
}

   //reads the default configuration of cluster from the configuration xml files
Configuration conf = new Configuration();

//Initializing the job with the default configuration of the cluster	
Job job = new Job(conf, "weather example");

//Assigning the driver class name
job.setJarByClass(Run.class);

//Key type coming out of mapper
job.setMapOutputKeyClass(Text.class);

//value type coming out of mapper
job.setMapOutputValueClass(Text.class);

//Defining the mapper class name
job.setMapperClass(MaxTemperatureMapper.class);

//Defining the reducer class name
job.setReducerClass(MaxTemperatureReducer.class);

//Defining input Format class which is responsible to parse the dataset into a key value pair
job.setInputFormatClass(TextInputFormat.class);

//Defining output Format class which is responsible to parse the dataset into a key value pair
job.setOutputFormatClass(TextOutputFormat.class);

//setting the second argument as a path in a path variable
Path OutputPath = new Path(args[1]);

//Configuring the input path from the filesystem into the job
FileInputFormat.addInputPath(job, new Path(args[0]));

//Configuring the output path from the filesystem into the job
FileOutputFormat.setOutputPath(job, new Path(args[1]));

//deleting the context path automatically from hdfs so that we don't have delete it explicitly
OutputPath.getFileSystem(conf).delete(OutputPath);

//exiting the job only if the flag value becomes false
System.exit(job.waitForCompletion(true) ? 0 : 1);

}
}
